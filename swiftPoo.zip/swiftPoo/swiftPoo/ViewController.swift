//
//  ViewController.swift
//  swiftPoo
//
//  Created by COTEMIG on 13/05/25.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var cachorroButton: UIButton!
    
    @IBOutlet weak var PassaroButton: UIButton!
    @IBOutlet weak var GatoButton: UIButton!
    @IBOutlet weak var LabelIdade: UILabel!
    @IBOutlet weak var ImageView: UIImageView!
    @IBOutlet weak var LabelNome: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        atualizarTelaComAnimal(gato)
    }
    let gato = Gatineo(nome: "Gato", idade: 3, imagem: "gatineo")
    let cachorro = Cachorrineo(nome: "Cachorro", idade: 5, imagem: "doggineo")
    let passarinho = Passarinho(nome: "Passarinho", idade: 1, imagem: "passarinho")

    
    
    func atualizarTelaComAnimal(_ animal: Animal) {
           LabelNome.text = animal.nome
           LabelIdade.text = "Idade: \(animal.idade)"
           ImageView.image = UIImage(named: animal.imagem)
           animal.som()
       }

       // IBAction para botão do gato
    @IBAction func btnCachorro(_ sender: Any) {
        atualizarTelaComAnimal(cachorro)
    }
    @IBAction func btnPassaro(_ sender: Any) {
        atualizarTelaComAnimal(passarinho)
    }
    
    @IBAction func btnGato(_ sender: Any) {
        atualizarTelaComAnimal(gato)
    }
    
    
    
}


