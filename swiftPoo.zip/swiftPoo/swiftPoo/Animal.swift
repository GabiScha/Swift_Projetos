//
//  Animal.swift
//  swiftPoo
//
//  Created by COTEMIG on 13/05/25.
//

import Foundation
import UIKit

class Animal{
    var nome = ""
    var idade = 0
    var imagem: String
    private var fome = 10
    
    func som (){}
    
    
    init(nome: String, idade: Int, imagem: String) {
        self.nome = nome
        self.idade = idade
        self.imagem = imagem
    }
    
    func Comer(){
        fome = 0
    }
    
}

class Gatineo:Animal {
    let felino = true
    
    override func som(){
            print("Miau")
    }
    
    
}
    
    class Cachorrineo:Animal {
        
        let canino = true
        
        override func som(){
                print("AU")
        }
    }


class Passarinho:Animal {
    let passaro = true
    
    override func som(){
            print("Piu")
    }
    
    
}
