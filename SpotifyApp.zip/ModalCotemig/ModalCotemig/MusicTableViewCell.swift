//
//  MusicTableViewCell.swift
//  ModalCotemig
//
//  Created by COTEMIG on 01/07/25.
//

import UIKit

class musicTableViewCell: UIViewController {

    @IBOutlet weak var NomeDaMusica: UILabel!
    @IBOutlet weak var NomeDoArtista: UILabel!

}
