//
//  TableViewController.swift
//  ModalCotemig
//
//  Created by COTEMIG on 01/07/25.
//

import Foundation

class TableViewController{
    
}
