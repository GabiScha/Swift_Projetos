//
//  ClassViewController.swift
//  ModalCotemig
//
//  Created by COTEMIG on 10/06/25.
//

import UIKit
import Foundation

class ClassViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        OutletSlider.maximumValue = 100.0
        // Do any additional setup after loading the view.
    }
    var estado = 1
    @IBOutlet weak var PlayButton: UIButton!
    @IBOutlet weak var OutletSlider: UISlider!
    
    
    var time = 0
    
    override func viewDidAppear(_ animated: Bool){
        OutletSlider.maximumValue = 100.0
    }
    
    
    @IBAction func SliderAction(_ sender: Any) {
        time = Int(OutletSlider.value)
    }
    
    @IBAction func BtnPlay(_ animated: Bool) {
        
        if (estado == 0){
            estado = 1
        }else{
            estado = 0
        }
        
        time = Int(OutletSlider.value)
        Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true){
            
            timer in
            self.time += 5
            
            self.OutletSlider.value = Float(self.time)
            
            if self.time >= 100 {
                            timer.invalidate()
                            print("Timer finalizado!")
            }
            
            if (self.estado == 0){
                self.PlayButton.setImage(UIImage(systemName: "pause.fill"), for: .normal)
            } else {
                timer.invalidate()
                print("Pausou")
                self.PlayButton.setImage(UIImage(systemName: "play.fill"), for: .normal)
            }
        }
        
        
        
        
        
    
        
    }

}
