//
//  ViewController.swift
//  ModalCotemig
//
//  Created by COTEMIG on 03/06/25.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    
    
    
}

